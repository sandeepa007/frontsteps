<h1>Property Management Company In City</h1>
<p>
  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</p>  


<div class="home-features">
	<h2 class="text-center">Flexible Management Solutions</h2>

	<div class="row">
		<div class="col-md-1 col-sm-2 col-md-offset-2">
			<span class="icons-coastal icon-pay"></span>
		</div>
		<div class="col-md-7 col-sm-10">
			<h3>ONLINE PAYMENTS</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur sed viverra sapien. Vivamus convallis augue vel eros imperdiet, et commodo quam blandit. Curabitur ut tellus fermentum, tempor ante sed, sollicitudin mi. Nulla nisl orci, malesuada eget velit.</p>
			<hr>
		</div>
	</div>
	<div class="row">
		<div class="col-md-1 col-sm-2 col-md-offset-2">
			<span class="icons-coastal icon-man"></span>
		</div>
		<div class="col-md-7 col-sm-10">
			<h3>PROPERTY MANAGEMENT</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur sed viverra sapien. Vivamus convallis augue vel eros imperdiet, et commodo quam blandit. Curabitur ut tellus fermentum, tempor ante sed, sollicitudin mi. Nulla nisl orci, malesuada eget velit.</p>
			<hr>
		</div>
	</div>
	<div class="row">
		<div class="col-md-1 col-sm-2 col-md-offset-2">
			<span class="icons-coastal icon-req"></span>
		</div>
		<div class="col-md-7 col-sm-10">
			<h3>MAINTENANCE REQUEST</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur sed viverra sapien. Vivamus convallis augue vel eros imperdiet, et commodo quam blandit. Curabitur ut tellus fermentum, tempor ante sed, sollicitudin mi. Nulla nisl orci, malesuada eget velit.</p>
			<hr>
		</div>
	</div>
</div><!-- .home-features -->