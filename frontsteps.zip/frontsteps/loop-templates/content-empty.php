<?php
/**
 * Content empty partial template.
 *
 * @package frontsteps
 */

the_content();
