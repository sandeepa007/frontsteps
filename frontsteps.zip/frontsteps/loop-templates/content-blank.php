<?php
/**
 * Blank content partial template.
 *
 * @package frontsteps
 */

the_content();
